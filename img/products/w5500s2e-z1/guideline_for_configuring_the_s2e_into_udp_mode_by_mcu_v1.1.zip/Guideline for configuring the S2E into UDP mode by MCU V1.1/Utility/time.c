#include "stm32f10x.h"
#include "time.h"
#include "uart.h"

/****************************************************
Function name:	TIM3_Int_Init
Parameter:			arr--reload value
								psc--Prescaler value
Return value:		null
Function:				Timer initialization
****************************************************/
extern uint16_t  RX2_Point;
void TIM3_Init(u16 arr,u16 psc)  
{  
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    NVIC_InitTypeDef NVIC_InitStructure;  
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //enable timer 
   //Timer TIM3 initialization
    TIM_TimeBaseStructure.TIM_Period = arr; //Set the reload value for the next update event     
    TIM_TimeBaseStructure.TIM_Prescaler =psc; //Set the Prescaler as the TIMx clock frequency divided factor  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //set Clock Division: TDTS = Tck_tim   
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  //set timer into count up mode 
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); //Initialize the time base structure according to the specified parameter
    TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE ); //enable Specified TIM3 interrupt--enable the update interrupt 
		//Interrupt priority NVIC configuration 
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;   //TIM3 interrupt  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;  //Set Preemption Priority to 3  
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  //Set SubPriority to 0  
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; //enable IRQ channel  
    NVIC_Init(&NVIC_InitStructure);  //Initialize NVIC registers  
    TIM_Cmd(TIM3, ENABLE);  //Enable TIMx                         
}  
  
/****************************************************
Function name:	TIM3_IRQHandler
Parameter:			null
Return value:		null
Function:				Handle Timer interrupt
****************************************************/
void TIM3_IRQHandler(void)   //TIM3 interrupt
{  
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)  // check the state of TIM3 update interrupt flag
    {  
  
        RX2_Point|=FRAME_LEN;			 //set highest bit to 1, mark receive finis
  
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update  );   //clear TIMx update interrupt flag   
        TIM_Cmd(TIM3, DISABLE); //cloes TIM3
    }  
}  

