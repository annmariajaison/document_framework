#ifndef _ATCOMMAND_H_
#define _ATCOMMAND_H_
#include "stm32f10x.h"
#include "stdio.h"
void Usart_Send(USART_TypeDef* USARTx,char *ch);

void UDP_Mode(void);







#endif




