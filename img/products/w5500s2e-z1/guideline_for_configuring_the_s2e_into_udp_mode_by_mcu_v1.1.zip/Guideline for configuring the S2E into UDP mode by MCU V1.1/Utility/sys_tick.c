#include "stm32f10x.h"
#include "sys_tick.h"

/****************************************************
Function name:	SysTickConfig
Parameter:			null
Return value:		null
Function:			  Initialize Systick
****************************************************/
void SysTickConfig(void)
{
	if(SysTick_Config(SystemCoreClock/1000000) == 1)// Initial value
	{                     //72000000
		while(1);
	}
	
		//close Systick
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
	
}
/****************************************************
Function name:	Delay_us
Parameter:			value of time need to delay(unit: us)
Return value:		null
Function:				delay specific us time
****************************************************/
u32 TimeDelay = 0;
void Delay_us(u32 time)
{
	TimeDelay = time;
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;//turn on Systick
	
	while(TimeDelay !=0);
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;//close Systick
}
/****************************************************
Function name:	Delay_ms
Parameter:			value of time need to delay(unit: ms)
Return value:		null
Function:				delay specific ms time
****************************************************/
void Delay_ms(u32 time)
{
	TimeDelay = time*1000;
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;//turn on Systick
	
	while(TimeDelay !=0);
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;//close Systick
}
/****************************************************
Function name:	SysTick_Handler
Parameter:			null
Return value:		null
Function:			handle the Systick interrupt
****************************************************/
void SysTick_Handler(void)
{
	if(TimeDelay > 0)
		TimeDelay--;
}








