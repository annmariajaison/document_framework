#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "ATCommand.H"
#include "sys_tick.h"
#include "uart.h"

extern uint8_t RecvBuff[RECV_LEN]; //receive the data from USART PORT
extern uint16_t RX2_Point; 
extern uint8_t Config_OK;
/****************************************************
Function name: 	Usart_Send
Parameter:			USARTx  --port number    ch  --value to send
								size    --value size
Return value:		null
Function:				Send data to S2E via USART2
****************************************************/
void Usart_Send(USART_TypeDef* USARTx,char *ch)
{
	printf("Send:%s",ch);
  while(*ch)
	{
	  USART_SendData(USARTx,(uint8_t) *ch++);  //Send 1 byte to USART2
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET); //Wait for sending finish 
	}	
}


/****************************************************
Function name: 	UDP_Mode
Parameter:			null
Return value:		null
Function:				Set S2E into UDP mode
****************************************************/
volatile uint8_t SendFlag=0;

void UDP_Mode(void)
{ 
  uint8_t RecvFlag=1;
	char *state;
	
  switch(SendFlag)
	{
	  case 0:
		{
			Usart_Send(USART2,"AT\r\n");//Terminal check
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)     //If receive data 
        {
					 state=strstr((char *)RecvBuff,"OK"); //check is there 'OK' in receive buffer
           if(state!=NULL)					//True
					 {
              RX2_Point=0;        //clear buffer pointer
				      RecvFlag=0;         //clear receive state flag
						  SendFlag=1;
					    printf("Recv:%s\r\n",RecvBuff);
			        memset(RecvBuff,0,RECV_LEN); 		//clear receive buffer
					 }
					 else{  
						 SendFlag=100;					//Failed to configure
						 RecvFlag=0;
					 } 
	      }	
	    }
	  }break;
	 case 1:
		{
			Usart_Send(USART2,"AT+ECHO=0\r\n");//(open --1/ close --0)  echo command 
      RecvFlag=1;			
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {   
					 state=strstr((char *)RecvBuff,"OK");
           if(state!=NULL)
					 {
              RX2_Point=0;
				      RecvFlag=0;
						  SendFlag=2;
					    printf("Recv:%s\r\n",RecvBuff);
			        memset(RecvBuff,0,RECV_LEN);   
					 }	
           else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }					 
	      }	
	    }
	  }break;
	 case 2:
		{
			Usart_Send(USART2,"AT+C1_OP=2\r\n");//Set into UDP mode
		  RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//If receive data 
					   SendFlag=3;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);			
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 3:
		{
			Usart_Send(USART2,"AT+IP_MODE=1\r\n");//set into DHCP mode
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)			//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flag
					   SendFlag=4;   
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);				     		
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 4:
		{
			Usart_Send(USART2,"AT+C1_PORT=5000\r\n");  //Configure the local port number
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)				//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flag
					   SendFlag=5;    
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);	 					
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break;
	 case 5:
		{
			Usart_Send(USART2,"AT+C1_CLI_IP1=192.168.1.100\r\n");//Set the remote host ip address
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)				//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flag
					   SendFlag=6;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);		
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break; 
	 case 6:
		{
			Usart_Send(USART2,"AT+C1_CLI_PP1=5000\r\n");//Set the remote lcoal server port number
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)				//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flag
					   SendFlag=7;    
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);		
	        }
				  else{  
						 SendFlag=100;
						 RecvFlag=0;
					 }
				 }
	    }
	  }break; 	
	 case 7:
		{
			Usart_Send(USART2,"AT+START_MODE=0\r\n");  //configure start mode (0--AT mode ,1--data mode)
			RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)				//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;				//clear receive state flag
					   SendFlag=8;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);
	        }
				  else{  
						 SendFlag=100;
					   RecvFlag=0;
					 }
				 }				
	    }
	  }break;	
	 case 8:
		{
			Usart_Send(USART2,"AT+EXIT\r\n");  //Save setting and enter the data mode
		  RecvFlag=1;		
		  while(RecvFlag)
	    { 
			  if(RX2_Point & FRAME_LEN)				//If receive data 
        {
					state=strstr((char *)RecvBuff,"OK");
					if(state!=NULL)
					{
             RX2_Point=0;
				     RecvFlag=0;			//clear receive state flag
					   SendFlag=99;     
					   printf("Recv:%s\r\n",RecvBuff);
			       memset(RecvBuff,0,RECV_LEN);
					}	
          else{  
						 SendFlag=100;
             RecvFlag=0;						
					 }
				 }					
	      }      
	    }break;
	 case 99:
	  {
			printf("UDP Config Success!\r\n");
			Config_OK=1;
	  }
		default:
			RecvFlag=100;break;
	 case 100:
		{
		   printf("UDP Config Fail!\r\n");
			 Config_OK=1;
		}break;
	  }	
 }




