/**
  ******************************************************************************
  * @file    WIZnet MDK5 Project Template  ../main.c 
  * @author  WIZnet Software Team
  * @version V1.0.0
  * @date    2017-07-28
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2017 WIZnet H.K. Ltd.</center></h2>
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h>
#include "uart.h"
#include "stdio.h"
#include "ATCommand.h"
#include "time.h"

/****************************************************
Function name:	main
Parameter:			null
Return value:		null
Function:				set S2E into UDP mode
****************************************************/
volatile uint8_t Config_OK=0;


int main(void)
{
	TIM3_Init(999,7199);     	//100ms interrupt for receive the data 
	USARTX_Init();          	//Port initialization
	
	while(!Config_OK)
	{
	  UDP_Mode();        			//set S2E into UDP mode
  }
}





/******************* (C) COPYRIGHT 2017 WIZnet H.K. Ltd. ****** END OF FILE ****/
